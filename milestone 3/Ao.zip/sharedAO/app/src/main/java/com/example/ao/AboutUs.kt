package com.example.ao

import android.os.Bundle
import androidx.activity.ComponentActivity

class AboutUs: ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about_page)
    }

}