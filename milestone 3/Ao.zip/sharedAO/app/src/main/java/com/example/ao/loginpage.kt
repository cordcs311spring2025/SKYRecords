package com.example.ao

import android.os.Bundle
import android.widget.TextView
import androidx.activity.ComponentActivity

class loginpage: ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_page)
    }

}